--
-- PostgreSQL database dump
--

\restrict zf93GDfzhNR21BBu677TWMtszeeqcpSaXXiLicsRULBFlaP5fMsmjNG25RYIEbK

-- Dumped from database version 15.18
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: timescaledb; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS timescaledb WITH SCHEMA public;


--
-- Name: EXTENSION timescaledb; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION timescaledb IS 'Enables scalable inserts and complex queries for time-series data (Community Edition)';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ledger_entries; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.ledger_entries (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id character varying(50) NOT NULL,
    variant_id text NOT NULL,
    quantity integer NOT NULL,
    reason character varying(50) NOT NULL,
    actor_id text NOT NULL,
    reference_id text,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.ledger_entries OWNER TO ddd_user;

--
-- Name: _direct_view_3; Type: VIEW; Schema: _timescaledb_internal; Owner: ddd_user
--

CREATE VIEW _timescaledb_internal._direct_view_3 AS
 SELECT public.time_bucket('1 day'::interval, ledger_entries.occurred_at) AS bucket,
    ledger_entries.tenant_id,
    ledger_entries.variant_id,
    COALESCE(sum(
        CASE
            WHEN (ledger_entries.quantity < 0) THEN abs(ledger_entries.quantity)
            ELSE 0
        END), (0)::bigint) AS units_dispatched,
    COALESCE(sum(
        CASE
            WHEN (ledger_entries.quantity > 0) THEN ledger_entries.quantity
            ELSE 0
        END), (0)::bigint) AS units_received,
    count(*) AS transaction_count
   FROM public.ledger_entries
  GROUP BY (public.time_bucket('1 day'::interval, ledger_entries.occurred_at)), ledger_entries.tenant_id, ledger_entries.variant_id;


ALTER TABLE _timescaledb_internal._direct_view_3 OWNER TO ddd_user;

--
-- Name: inventory_transactions; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.inventory_transactions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id character varying(50) NOT NULL,
    product_id uuid NOT NULL,
    type character varying(50) NOT NULL,
    quantity_change integer NOT NULL,
    condition character varying(50) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    reference_id text
);


ALTER TABLE public.inventory_transactions OWNER TO ddd_user;

--
-- Name: _hyper_1_78_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: ddd_user
--

CREATE TABLE _timescaledb_internal._hyper_1_78_chunk (
    CONSTRAINT constraint_78 CHECK (((created_at >= '2026-07-16 00:00:00+00'::timestamp with time zone) AND (created_at < '2026-07-23 00:00:00+00'::timestamp with time zone)))
)
INHERITS (public.inventory_transactions);


ALTER TABLE _timescaledb_internal._hyper_1_78_chunk OWNER TO ddd_user;

--
-- Name: _materialized_hypertable_3; Type: TABLE; Schema: _timescaledb_internal; Owner: ddd_user
--

CREATE TABLE _timescaledb_internal._materialized_hypertable_3 (
    bucket timestamp with time zone NOT NULL,
    tenant_id character varying(50),
    variant_id text,
    units_dispatched bigint,
    units_received bigint,
    transaction_count bigint
);


ALTER TABLE _timescaledb_internal._materialized_hypertable_3 OWNER TO ddd_user;

--
-- Name: _hyper_3_44_chunk; Type: TABLE; Schema: _timescaledb_internal; Owner: ddd_user
--

CREATE TABLE _timescaledb_internal._hyper_3_44_chunk (
    CONSTRAINT constraint_44 CHECK (((bucket >= '2026-05-07 00:00:00+00'::timestamp with time zone) AND (bucket < '2026-07-16 00:00:00+00'::timestamp with time zone)))
)
INHERITS (_timescaledb_internal._materialized_hypertable_3);


ALTER TABLE _timescaledb_internal._hyper_3_44_chunk OWNER TO ddd_user;

--
-- Name: _partial_view_3; Type: VIEW; Schema: _timescaledb_internal; Owner: ddd_user
--

CREATE VIEW _timescaledb_internal._partial_view_3 AS
 SELECT public.time_bucket('1 day'::interval, ledger_entries.occurred_at) AS bucket,
    ledger_entries.tenant_id,
    ledger_entries.variant_id,
    COALESCE(sum(
        CASE
            WHEN (ledger_entries.quantity < 0) THEN abs(ledger_entries.quantity)
            ELSE 0
        END), (0)::bigint) AS units_dispatched,
    COALESCE(sum(
        CASE
            WHEN (ledger_entries.quantity > 0) THEN ledger_entries.quantity
            ELSE 0
        END), (0)::bigint) AS units_received,
    count(*) AS transaction_count
   FROM public.ledger_entries
  GROUP BY (public.time_bucket('1 day'::interval, ledger_entries.occurred_at)), ledger_entries.tenant_id, ledger_entries.variant_id;


ALTER TABLE _timescaledb_internal._partial_view_3 OWNER TO ddd_user;

--
-- Name: api_tokens; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.api_tokens (
    id text NOT NULL,
    user_id uuid NOT NULL,
    tenant_id character varying(50) NOT NULL,
    token_hash text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.api_tokens OWNER TO ddd_user;

--
-- Name: audit_discrepancies; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.audit_discrepancies (
    id character varying(255) NOT NULL,
    tenant_id character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    reference_id character varying(255) NOT NULL,
    external_ref_id character varying(255),
    description text NOT NULL,
    status character varying(50) DEFAULT 'OPEN'::character varying,
    occurred_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    resolved_at timestamp without time zone,
    resolution_notes text
);


ALTER TABLE public.audit_discrepancies OWNER TO ddd_user;

--
-- Name: barcodes; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.barcodes (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    value text NOT NULL,
    variant_id text NOT NULL,
    symbology character varying(50),
    source character varying(50),
    is_primary boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.barcodes OWNER TO ddd_user;

--
-- Name: catalog_products; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.catalog_products (
    tenant_id text DEFAULT 'system'::text NOT NULL,
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name text NOT NULL,
    description text,
    department text NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.catalog_products OWNER TO ddd_user;

--
-- Name: catalog_variants; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.catalog_variants (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    product_id uuid NOT NULL,
    sku text NOT NULL,
    attributes jsonb DEFAULT '{}'::jsonb NOT NULL,
    price numeric(10,2) DEFAULT 0.00 NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.catalog_variants OWNER TO ddd_user;

--
-- Name: compliance_ledgers; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.compliance_ledgers (
    id character varying(50) NOT NULL,
    tenant_id character varying(50) NOT NULL,
    actor_id character varying(50) NOT NULL,
    event_type character varying(100) NOT NULL,
    sequence_number integer NOT NULL,
    previous_hash character varying(64) NOT NULL,
    current_hash character varying(64) NOT NULL,
    signature character varying(64) NOT NULL,
    payload text NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.compliance_ledgers OWNER TO ddd_user;

--
-- Name: daily_stock_velocity; Type: VIEW; Schema: public; Owner: ddd_user
--

CREATE VIEW public.daily_stock_velocity AS
 SELECT _materialized_hypertable_3.bucket,
    _materialized_hypertable_3.tenant_id,
    _materialized_hypertable_3.variant_id,
    _materialized_hypertable_3.units_dispatched,
    _materialized_hypertable_3.units_received,
    _materialized_hypertable_3.transaction_count
   FROM _timescaledb_internal._materialized_hypertable_3;


ALTER TABLE public.daily_stock_velocity OWNER TO ddd_user;

--
-- Name: demand_forecasts; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.demand_forecasts (
    id character varying(50) NOT NULL,
    sku character varying(50) NOT NULL,
    location_id character varying(50) NOT NULL,
    forecasted_quantity integer NOT NULL,
    period_start timestamp without time zone NOT NULL,
    period_end timestamp without time zone NOT NULL,
    confidence_level numeric NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.demand_forecasts OWNER TO ddd_user;

--
-- Name: inventory_cost_layers; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.inventory_cost_layers (
    id character varying(50) NOT NULL,
    tenant_id character varying(50) NOT NULL,
    variant_id character varying(50) NOT NULL,
    original_quantity integer NOT NULL,
    remaining_quantity integer NOT NULL,
    unit_cost_cents bigint NOT NULL,
    purchase_order_id character varying(50),
    received_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    serial_number character varying(100),
    lot_number character varying(100),
    expiration_date timestamp without time zone
);


ALTER TABLE public.inventory_cost_layers OWNER TO ddd_user;

--
-- Name: inventory_count_items; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.inventory_count_items (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    inventory_count_id uuid NOT NULL,
    product_id uuid,
    sku text NOT NULL,
    location_id character varying(50) NOT NULL,
    counted_quantity integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.inventory_count_items OWNER TO ddd_user;

--
-- Name: inventory_counts; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.inventory_counts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id character varying(50) NOT NULL,
    status character varying(50) NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    completed_at timestamp with time zone
);


ALTER TABLE public.inventory_counts OWNER TO ddd_user;

--
-- Name: journal_entries; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.journal_entries (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id character varying(50) NOT NULL,
    entry_date date NOT NULL,
    description text,
    reference_id text,
    method character varying(50),
    lines jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.journal_entries OWNER TO ddd_user;

--
-- Name: kit_components; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.kit_components (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    kit_id uuid NOT NULL,
    variant_id text NOT NULL,
    quantity integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.kit_components OWNER TO ddd_user;

--
-- Name: kits; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.kits (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    sku text NOT NULL,
    name text NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.kits OWNER TO ddd_user;

--
-- Name: locations; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.locations (
    id character varying(50) NOT NULL,
    name text NOT NULL,
    type character varying(50) NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.locations OWNER TO ddd_user;

--
-- Name: netsuite_journal_mappings; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.netsuite_journal_mappings (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    journal_entry_id uuid NOT NULL,
    netsuite_journal_id character varying(50) NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.netsuite_journal_mappings OWNER TO ddd_user;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.notifications (
    id character varying(50) NOT NULL,
    tenant_id character varying(50) NOT NULL,
    title character varying(255) NOT NULL,
    message text NOT NULL,
    type character varying(50) NOT NULL,
    is_read boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.notifications OWNER TO ddd_user;

--
-- Name: outbox_events; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.outbox_events (
    id character varying(50) NOT NULL,
    event_name character varying(255) NOT NULL,
    payload text NOT NULL,
    occurred_on timestamp without time zone NOT NULL,
    processed_at timestamp without time zone,
    attempts integer DEFAULT 0 NOT NULL,
    last_error text,
    next_attempt_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.outbox_events OWNER TO ddd_user;

--
-- Name: outbox_messages; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.outbox_messages (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    event_type character varying(255) NOT NULL,
    payload jsonb NOT NULL,
    occurred_at timestamp with time zone DEFAULT now(),
    processed_at timestamp with time zone
);


ALTER TABLE public.outbox_messages OWNER TO ddd_user;

--
-- Name: product_locations; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.product_locations (
    product_id uuid NOT NULL,
    location_id character varying(50) NOT NULL,
    stock_quantity integer DEFAULT 0 NOT NULL,
    open_box_quantity integer DEFAULT 0 NOT NULL,
    damaged_quantity integer DEFAULT 0 NOT NULL,
    allocated_quantity integer DEFAULT 0 NOT NULL,
    in_transit_quantity integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.product_locations OWNER TO ddd_user;

--
-- Name: product_uom_configurations; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.product_uom_configurations (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    variant_id text NOT NULL,
    base_unit character varying(50) NOT NULL,
    purchase_unit character varying(50),
    sale_unit character varying(50),
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.product_uom_configurations OWNER TO ddd_user;

--
-- Name: products; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.products (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id character varying(50) NOT NULL,
    sku text NOT NULL,
    name text NOT NULL,
    department text NOT NULL,
    reorder_threshold integer DEFAULT 10 NOT NULL,
    version_id integer DEFAULT 1 NOT NULL,
    weight_grams integer,
    volume_cubic_meters numeric,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.products OWNER TO ddd_user;

--
-- Name: purchase_order_items; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.purchase_order_items (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    purchase_order_id uuid NOT NULL,
    variant_id character varying(50) NOT NULL,
    quantity integer NOT NULL,
    received_quantity integer DEFAULT 0 NOT NULL,
    unit_cost_cents integer NOT NULL
);


ALTER TABLE public.purchase_order_items OWNER TO ddd_user;

--
-- Name: purchase_orders; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.purchase_orders (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    purchase_order_number character varying(100) NOT NULL,
    vendor_id character varying(50) NOT NULL,
    tenant_id character varying(50) NOT NULL,
    status character varying(50) NOT NULL,
    location_id character varying(50) NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.purchase_orders OWNER TO ddd_user;

--
-- Name: quarantine_items; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.quarantine_items (
    id character varying(50) NOT NULL,
    tenant_id character varying(50) NOT NULL,
    variant_id character varying(50) NOT NULL,
    quantity integer NOT NULL,
    reason text NOT NULL,
    status character varying(50) NOT NULL,
    location_id character varying(50) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    resolved_at timestamp without time zone
);


ALTER TABLE public.quarantine_items OWNER TO ddd_user;

--
-- Name: queued_jobs; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.queued_jobs (
    id character varying(50) NOT NULL,
    tenant_id character varying(50) NOT NULL,
    listener_class character varying(255) NOT NULL,
    event_data text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    reserved_at timestamp without time zone,
    available_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.queued_jobs OWNER TO ddd_user;

--
-- Name: quickbooks_journal_mappings; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.quickbooks_journal_mappings (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    journal_entry_id uuid NOT NULL,
    quickbooks_journal_id character varying(50) NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.quickbooks_journal_mappings OWNER TO ddd_user;

--
-- Name: reorder_policies; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.reorder_policies (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    sku character varying(50) NOT NULL,
    location_id character varying(50) NOT NULL,
    reorder_point integer NOT NULL,
    reorder_quantity integer NOT NULL,
    safety_stock integer NOT NULL,
    dynamic_rop_enabled boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.reorder_policies OWNER TO ddd_user;

--
-- Name: rma_items; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.rma_items (
    id character varying(50) NOT NULL,
    rma_id character varying(50) NOT NULL,
    variant_id character varying(50) NOT NULL,
    quantity integer NOT NULL,
    received_quantity integer DEFAULT 0 NOT NULL,
    unit_cost_cents integer NOT NULL,
    status character varying(50) NOT NULL,
    disposition character varying(50),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.rma_items OWNER TO ddd_user;

--
-- Name: rmas; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.rmas (
    id character varying(50) NOT NULL,
    rma_number character varying(100) NOT NULL,
    tenant_id character varying(50) NOT NULL,
    customer_id character varying(100) NOT NULL,
    location_id character varying(50) NOT NULL,
    status character varying(50) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.rmas OWNER TO ddd_user;

--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.role_permissions (
    role_id character varying(20) NOT NULL,
    permission text NOT NULL
);


ALTER TABLE public.role_permissions OWNER TO ddd_user;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.roles (
    id character varying(20) NOT NULL,
    name text NOT NULL
);


ALTER TABLE public.roles OWNER TO ddd_user;

--
-- Name: serialized_items; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.serialized_items (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    variant_id text NOT NULL,
    serial_number text NOT NULL,
    tenant_id character varying(50) NOT NULL,
    location_id character varying(50),
    status character varying(50) NOT NULL,
    history jsonb DEFAULT '[]'::jsonb,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.serialized_items OWNER TO ddd_user;

--
-- Name: shipments; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.shipments (
    id character varying(50) NOT NULL,
    sku character varying(50) NOT NULL,
    quantity integer NOT NULL,
    destination_address text NOT NULL,
    carrier character varying(50) NOT NULL,
    tracking_number character varying(100),
    label_url text,
    shipping_rate_cents integer NOT NULL,
    status character varying(50) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.shipments OWNER TO ddd_user;

--
-- Name: shopify_location_mappings; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.shopify_location_mappings (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    our_location_id character varying(50) NOT NULL,
    shopify_location_id character varying(50) NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.shopify_location_mappings OWNER TO ddd_user;

--
-- Name: shopify_sku_mappings; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.shopify_sku_mappings (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    sku text NOT NULL,
    shopify_inventory_item_id character varying(50) NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.shopify_sku_mappings OWNER TO ddd_user;

--
-- Name: shopify_sync_failures; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.shopify_sync_failures (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id character varying(50) NOT NULL,
    sku text NOT NULL,
    location_id character varying(50) NOT NULL,
    quantity integer NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    last_error text,
    status character varying(50) DEFAULT 'pending'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.shopify_sync_failures OWNER TO ddd_user;

--
-- Name: stock_onboarding_items; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.stock_onboarding_items (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    onboarding_id uuid NOT NULL,
    variant_id text NOT NULL,
    quantity integer DEFAULT 0 NOT NULL,
    unit_cost_cents integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.stock_onboarding_items OWNER TO ddd_user;

--
-- Name: stock_onboardings; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.stock_onboardings (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id character varying(50) NOT NULL,
    location_id character varying(50) NOT NULL,
    as_of_date date NOT NULL,
    status character varying(50) DEFAULT 'draft'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.stock_onboardings OWNER TO ddd_user;

--
-- Name: tenants; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.tenants (
    id character varying(50) NOT NULL,
    name text NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.tenants OWNER TO ddd_user;

--
-- Name: uom_conversion_rules; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.uom_conversion_rules (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    configuration_id uuid NOT NULL,
    unit character varying(50) NOT NULL,
    factor_to_base numeric NOT NULL,
    label text
);


ALTER TABLE public.uom_conversion_rules OWNER TO ddd_user;

--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.user_roles (
    user_id uuid NOT NULL,
    role_id character varying(20) NOT NULL
);


ALTER TABLE public.user_roles OWNER TO ddd_user;

--
-- Name: users; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id character varying(50) NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    name text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.users OWNER TO ddd_user;

--
-- Name: warehouse_locations; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.warehouse_locations (
    id character varying(50) NOT NULL,
    warehouse_id character varying(50) NOT NULL,
    zone character varying(50) NOT NULL,
    aisle character varying(50) NOT NULL,
    rack character varying(50) NOT NULL,
    shelf character varying(50) NOT NULL,
    bin character varying(50) NOT NULL,
    max_weight_grams integer NOT NULL,
    max_volume_cubic_meters numeric NOT NULL,
    grid_x integer DEFAULT 0 NOT NULL,
    grid_y integer DEFAULT 0 NOT NULL,
    width integer DEFAULT 1 NOT NULL,
    height integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.warehouse_locations OWNER TO ddd_user;

--
-- Name: webhook_deliveries; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.webhook_deliveries (
    id character varying(255) NOT NULL,
    tenant_id character varying(255) NOT NULL,
    subscription_id character varying(255) NOT NULL,
    event_type character varying(255) NOT NULL,
    payload text NOT NULL,
    status character varying(50) DEFAULT 'Pending'::character varying NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    last_error text,
    next_attempt_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    processed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.webhook_deliveries OWNER TO ddd_user;

--
-- Name: webhook_subscriptions; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.webhook_subscriptions (
    id character varying(255) NOT NULL,
    tenant_id character varying(255) NOT NULL,
    target_url character varying(500) NOT NULL,
    secret character varying(255) NOT NULL,
    event_types text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.webhook_subscriptions OWNER TO ddd_user;

--
-- Name: xero_journal_mappings; Type: TABLE; Schema: public; Owner: ddd_user
--

CREATE TABLE public.xero_journal_mappings (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    journal_entry_id uuid NOT NULL,
    xero_journal_id character varying(50) NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.xero_journal_mappings OWNER TO ddd_user;

--
-- Name: _hyper_1_78_chunk id; Type: DEFAULT; Schema: _timescaledb_internal; Owner: ddd_user
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_78_chunk ALTER COLUMN id SET DEFAULT public.uuid_generate_v4();


--
-- Name: _hyper_1_78_chunk created_at; Type: DEFAULT; Schema: _timescaledb_internal; Owner: ddd_user
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_78_chunk ALTER COLUMN created_at SET DEFAULT now();


--
-- Data for Name: hypertable; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: ddd_user
--

COPY _timescaledb_catalog.hypertable (id, schema_name, table_name, associated_schema_name, associated_table_prefix, num_dimensions, chunk_sizing_func_schema, chunk_sizing_func_name, chunk_target_size, compression_state, compressed_hypertable_id, status) FROM stdin;
1	public	inventory_transactions	_timescaledb_internal	_hyper_1	1	_timescaledb_functions	calculate_chunk_interval	0	0	\N	0
2	public	ledger_entries	_timescaledb_internal	_hyper_2	1	_timescaledb_functions	calculate_chunk_interval	0	0	\N	0
3	_timescaledb_internal	_materialized_hypertable_3	_timescaledb_internal	_hyper_3	1	_timescaledb_functions	calculate_chunk_interval	0	0	\N	0
\.


--
-- Data for Name: bgw_job; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: ddd_user
--

COPY _timescaledb_catalog.bgw_job (id, application_name, schedule_interval, max_runtime, max_retries, retry_period, proc_schema, proc_name, owner, scheduled, fixed_schedule, initial_start, hypertable_id, config, check_schema, check_name, timezone) FROM stdin;
1000	Refresh Continuous Aggregate Policy [1000]	01:00:00	00:00:00	-1	01:00:00	_timescaledb_functions	policy_refresh_continuous_aggregate	ddd_user	t	f	\N	3	{"end_offset": "01:00:00", "start_offset": "1 mon", "mat_hypertable_id": 3}	_timescaledb_functions	policy_refresh_continuous_aggregate_check	\N
\.


--
-- Data for Name: chunk; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: ddd_user
--

COPY _timescaledb_catalog.chunk (id, hypertable_id, schema_name, table_name, compressed_chunk_id, status, osm_chunk, creation_time) FROM stdin;
78	1	_timescaledb_internal	_hyper_1_78_chunk	\N	0	f	2026-07-18 05:05:27.512357+00
44	3	_timescaledb_internal	_hyper_3_44_chunk	\N	0	f	2026-07-17 23:03:54.751316+00
\.


--
-- Data for Name: chunk_column_stats; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: ddd_user
--

COPY _timescaledb_catalog.chunk_column_stats (id, hypertable_id, chunk_id, column_name, range_start, range_end, valid) FROM stdin;
\.


--
-- Data for Name: compression_chunk_size; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: ddd_user
--

COPY _timescaledb_catalog.compression_chunk_size (chunk_id, compressed_chunk_id, uncompressed_heap_size, uncompressed_toast_size, uncompressed_index_size, compressed_heap_size, compressed_toast_size, compressed_index_size, numrows_pre_compression, numrows_post_compression, numrows_frozen_immediately) FROM stdin;
\.


--
-- Data for Name: compression_settings; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: ddd_user
--

COPY _timescaledb_catalog.compression_settings (relid, compress_relid, segmentby, orderby, orderby_desc, orderby_nullsfirst, index) FROM stdin;
\.


--
-- Data for Name: continuous_agg; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: ddd_user
--

COPY _timescaledb_catalog.continuous_agg (mat_hypertable_id, raw_hypertable_id, parent_mat_hypertable_id, user_view_schema, user_view_name, partial_view_schema, partial_view_name, direct_view_schema, direct_view_name, materialized_only, schema_change_timestamp) FROM stdin;
3	2	\N	public	daily_stock_velocity	_timescaledb_internal	_partial_view_3	_timescaledb_internal	_direct_view_3	t	\N
\.


--
-- Data for Name: continuous_aggs_bucket_function; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: ddd_user
--

COPY _timescaledb_catalog.continuous_aggs_bucket_function (mat_hypertable_id, bucket_func, bucket_width, bucket_origin, bucket_offset, bucket_timezone, bucket_fixed_width) FROM stdin;
3	public.time_bucket(interval,timestamp with time zone)	1 day	\N	\N	\N	t
\.


--
-- Data for Name: continuous_aggs_hypertable_invalidation_log; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: ddd_user
--

COPY _timescaledb_catalog.continuous_aggs_hypertable_invalidation_log (hypertable_id, lowest_modified_value, greatest_modified_value) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_invalidation_threshold; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: ddd_user
--

COPY _timescaledb_catalog.continuous_aggs_invalidation_threshold (hypertable_id, watermark) FROM stdin;
2	1784419200000000
\.


--
-- Data for Name: continuous_aggs_jobs_refresh_ranges; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: ddd_user
--

COPY _timescaledb_catalog.continuous_aggs_jobs_refresh_ranges (materialization_id, start_range, end_range, pid, job_id, created_at) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_materialization_invalidation_log; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: ddd_user
--

COPY _timescaledb_catalog.continuous_aggs_materialization_invalidation_log (materialization_id, lowest_modified_value, greatest_modified_value) FROM stdin;
3	-9223372036854775808	1781654399999999
3	-9223372036854775808	1781740799999999
3	-9223372036854775808	1781827199999999
3	-9223372036854775808	1781827199999999
3	-9223372036854775808	1781827199999999
3	-9223372036854775808	1781827199999999
3	1784419200000000	9223372036854775807
\.


--
-- Data for Name: continuous_aggs_materialization_ranges; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: ddd_user
--

COPY _timescaledb_catalog.continuous_aggs_materialization_ranges (materialization_id, lowest_modified_value, greatest_modified_value) FROM stdin;
\.


--
-- Data for Name: continuous_aggs_watermark; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: ddd_user
--

COPY _timescaledb_catalog.continuous_aggs_watermark (mat_hypertable_id, watermark) FROM stdin;
3	1784160000000000
\.


--
-- Data for Name: dimension; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: ddd_user
--

COPY _timescaledb_catalog.dimension (id, hypertable_id, column_name, column_type, aligned, num_slices, partitioning_func_schema, partitioning_func, interval_length, compress_interval_length, integer_now_func_schema, integer_now_func) FROM stdin;
1	1	created_at	timestamp with time zone	t	\N	\N	\N	604800000000	\N	\N	\N
2	2	occurred_at	timestamp with time zone	t	\N	\N	\N	604800000000	\N	\N	\N
3	3	bucket	timestamp with time zone	t	\N	\N	\N	6048000000000	\N	\N	\N
\.


--
-- Data for Name: dimension_slice; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: ddd_user
--

COPY _timescaledb_catalog.dimension_slice (id, chunk_id, dimension_id, range_start, range_end) FROM stdin;
78	78	1	1784160000000000	1784764800000000
44	44	3	1778112000000000	1784160000000000
\.


--
-- Data for Name: metadata; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: ddd_user
--

COPY _timescaledb_catalog.metadata (key, value, include_in_telemetry) FROM stdin;
install_timestamp	2026-07-16 18:26:52.768857+00	t
timescaledb_version	2.28.1	f
exported_uuid	f0fbe3ab-c4bd-433a-a78d-b9f4a5e97774	t
\.


--
-- Data for Name: tablespace; Type: TABLE DATA; Schema: _timescaledb_catalog; Owner: ddd_user
--

COPY _timescaledb_catalog.tablespace (id, hypertable_id, tablespace_name) FROM stdin;
\.


--
-- Data for Name: _hyper_1_78_chunk; Type: TABLE DATA; Schema: _timescaledb_internal; Owner: ddd_user
--

COPY _timescaledb_internal._hyper_1_78_chunk (id, tenant_id, product_id, type, quantity_change, condition, created_at, reference_id) FROM stdin;
2bb15684-4165-4963-b6e1-f8d9439837f1	tenant-dd82f00c	2f6f7775-fc7a-4b04-92c4-94036e763f1b	receipt	6	new	2026-07-18 05:06:26+00	RECEIVE_IN_TRANSIT
\.


--
-- Data for Name: _hyper_3_44_chunk; Type: TABLE DATA; Schema: _timescaledb_internal; Owner: ddd_user
--

COPY _timescaledb_internal._hyper_3_44_chunk (bucket, tenant_id, variant_id, units_dispatched, units_received, transaction_count) FROM stdin;
\.


--
-- Data for Name: _materialized_hypertable_3; Type: TABLE DATA; Schema: _timescaledb_internal; Owner: ddd_user
--

COPY _timescaledb_internal._materialized_hypertable_3 (bucket, tenant_id, variant_id, units_dispatched, units_received, transaction_count) FROM stdin;
\.


--
-- Data for Name: api_tokens; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.api_tokens (id, user_id, tenant_id, token_hash, expires_at, created_at) FROM stdin;
tok_6a5b09b1b0f097.33760653	6d9534c0-dc83-45f3-9687-68765cdde776	tenant-dd82f00c	2b605653e9899c5b33d8ce0630983ab9a3dd057db2cf5a67e9850e3c9bec9078	2026-08-17 05:05:53+00	2026-07-18 05:05:53+00
\.


--
-- Data for Name: audit_discrepancies; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.audit_discrepancies (id, tenant_id, type, reference_id, external_ref_id, description, status, occurred_at, resolved_at, resolution_notes) FROM stdin;
b07144cc-9cac-4156-bb86-a79df846e41f	tenant-a63e3aaf	SHOPIFY_STOCK_MISMATCH	SKU-DIFF:LOC-STOREFRONT	inv-item-123	Shopify stock mismatch for SKU SKU-DIFF at location LOC-STOREFRONT. Local: 0, Shopify: 10	OPEN	2026-07-18 04:22:22	\N	\N
c8209371-e7c9-487a-bc31-22c534b7cc6e	tenant-a63e3aaf	ACCOUNTING_JOURNAL_MISSING	ad587eb9-9074-4a88-908f-54d9cc114730	\N	Journal entry ad587eb9-9074-4a88-908f-54d9cc114730 (Test unmapped journal) is not mapped to any external accounting transaction.	OPEN	2026-07-18 04:22:28	\N	\N
\.


--
-- Data for Name: barcodes; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.barcodes (id, value, variant_id, symbology, source, is_primary, created_at) FROM stdin;
\.


--
-- Data for Name: catalog_products; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.catalog_products (tenant_id, id, name, description, department, created_at) FROM stdin;
\.


--
-- Data for Name: catalog_variants; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.catalog_variants (id, product_id, sku, attributes, price, created_at) FROM stdin;
\.


--
-- Data for Name: compliance_ledgers; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.compliance_ledgers (id, tenant_id, actor_id, event_type, sequence_number, previous_hash, current_hash, signature, payload, created_at) FROM stdin;
7daab57bced1f6de3cea3305f651afb5	tenant-2679e841	1bc4e1ba-8f25-4e7a-bc70-a868464dd9a8	STOCK_ADJUSTED	3	a21a468429efc6288330e3d0ada7870a3eefb793aca234c3130715844950252c	dad3dc008445b088fa1c3de905bf8b055529acfbcebdc96c408d0e6eb2284cde	f8a670ad209654f0a1933b861af4104fb6924a871edb11e1889eaeb6cbc68f01	{"variant_id":"CAT-SKU-1","quantity":-6,"reason":"dispatch","reference_id":null,"occurred_at":"2026-07-18 04:24:41"}	2026-07-18 04:24:42+00
5e7e121f1eb6d31f4fa1450655f290c6	tenant-1e336d48	99c02e67-d06e-476a-a0a1-082f188ecf34	STOCK_ADJUSTED	2	6a18586aafdccadeaa4c2ba69948e5cdcfdb618d17f0a56cdc1ca05a07886cde	9b92d7b871f25dc1ceb7991563bfa1e1292cf5517054c59016b7c8e5be2d6309	fa6ba47dc41b140c67bd98f079426a103e2e6332b7975a5ad7f86057d271d4b5	{"variant_id":"d30f061f-8fac-47eb-b610-a8a534fb96cf","quantity":-1,"reason":"sale","reference_id":"SALE-HTTP-200","occurred_at":"2026-07-18 04:33:36"}	2026-07-18 04:33:36+00
4f2309a147df2ee112ee4748b03e7892	tenant-78905ea0	fc2d175b-6e0c-47ba-aae5-da1ee36e4e28	STOCK_ADJUSTED	1	0000000000000000000000000000000000000000000000000000000000000000	bb7db9248f37561fb331fcac8e98738eb9c8edf168a6fd729ab70580c0763af2	a39cb6c5d03e56126946a72460db697914b21017137836edfd0ff026b2beae6a	{"variant_id":"720b83be-419f-4f82-a95b-4ef4b949cc98","quantity":-6,"reason":"kit_sale","reference_id":"SALE-KIT-E2E-100","occurred_at":"2026-07-18 04:39:27"}	2026-07-18 04:39:29+00
82782da61ba24dfc5357b34bc2d1c825	tenant-7f990c1b	36fbf5ca-87a6-4a47-ac2e-8486d190d81c	STOCK_ADJUSTED	2	48d3236bfd3aec7a8f82e8a3d60d670b2a75494159ee07568fbc6ce11668de8d	e7ad144991bfa0df622bd3b7fdcb92324584424b7988711bb25d858dccd68f46	02bd0e6dd935716c7444e91bcc50bc4bdcecc6d002e3455b0e8f84e66826b21f	{"variant_id":"ROUTE-SKU-1","quantity":5,"reason":"purchase_receipt","reference_id":null,"occurred_at":"2026-07-18 04:41:11"}	2026-07-18 04:41:12+00
0f33d13f602f32c13fe98003105402ef	tenant-2679e841	1bc4e1ba-8f25-4e7a-bc70-a868464dd9a8	STOCK_ADJUSTED	1	0000000000000000000000000000000000000000000000000000000000000000	797feb3d87b45b62e3e186e1397eccedc83f255061fd96c9721660c38890a539	6c838de62747491b0a0cd1eeab1a57fde049e8d32ca0958d8c7d31edb73d5214	{"variant_id":"CAT-SKU-1","quantity":20,"reason":"purchase_receipt","reference_id":null,"occurred_at":"2026-07-18 04:24:19"}	2026-07-18 04:24:19+00
cd09792d1e4ed9f6910512c46ba71395	tenant-c255bb54	6b1839e1-7c21-4bc3-95e8-9617e0a81f56	STOCK_ADJUSTED	1	0000000000000000000000000000000000000000000000000000000000000000	6882e98621e6b28304764de504c473b5757aee68320cb7821b953b0ac2b2d482	6ee7cd6064b26cd64abafe1401037c8a9ffd2a2e01b842dafbc9a28c84d21876	{"variant_id":"IPHONE-15","quantity":50,"reason":"purchase_receipt","reference_id":null,"occurred_at":"2026-07-18 04:25:42"}	2026-07-18 04:25:44+00
23e035dfcbeba70c16f1facd107ada05	tenant-5289896b	532ed2df-8b3d-4a0e-8ab3-e287c5ce56aa	STOCK_ADJUSTED	1	0000000000000000000000000000000000000000000000000000000000000000	1747c524e32a3bcbc0d50045f51792ecb54540ff07b0c9bbc707199c1283db28	8d67260bac38b01c30503accf509ab1ac2594fa2a299e7d23db930fe64406eda	{"variant_id":"36d9a767-bdc0-486c-9d9c-de63a086d767","quantity":1,"reason":"purchase_receipt","reference_id":"PO-69043df4","occurred_at":"2026-07-18 04:39:05"}	2026-07-18 04:39:07+00
728f30abaa7de4c8f96102a2babc0f0a	tenant-7f990c1b	36fbf5ca-87a6-4a47-ac2e-8486d190d81c	STOCK_ADJUSTED	1	0000000000000000000000000000000000000000000000000000000000000000	48d3236bfd3aec7a8f82e8a3d60d670b2a75494159ee07568fbc6ce11668de8d	7ff46ee1e8db78240d488c809c5b997b696749965f42e252d4c6213bd7634240	{"variant_id":"ROUTE-SKU-1","quantity":5,"reason":"purchase_receipt","reference_id":null,"occurred_at":"2026-07-18 04:40:54"}	2026-07-18 04:40:55+00
a44156e6e12b7694f317246b30dfcb9e	tenant-a267a050	703da0a3-6884-4f61-b82d-ab6ce461dea0	STOCK_ADJUSTED	1	0000000000000000000000000000000000000000000000000000000000000000	54ffa0d1975906fe8c39485978c77a8739b4cc4b3cc7485395c6cefa26fa722e	62233534219ba97b52c54892365c5a0de10473530adf23d1f3b4e4f652326ace	{"variant_id":"TSHIRT-SM-RED","quantity":30,"reason":"purchase_receipt","reference_id":null,"occurred_at":"2026-07-18 04:46:47"}	2026-07-18 04:46:48+00
b1cd8dcbf6311343a6ece3ec4806d230	tenant-2679e841	1bc4e1ba-8f25-4e7a-bc70-a868464dd9a8	STOCK_ADJUSTED	2	797feb3d87b45b62e3e186e1397eccedc83f255061fd96c9721660c38890a539	a21a468429efc6288330e3d0ada7870a3eefb793aca234c3130715844950252c	2c1e4dfbe7179ec51254e3358ec1c3a7ff19a418e46101eb8ce6a3eea37403bc	{"variant_id":"CAT-SKU-1","quantity":-5,"reason":"dispatch","reference_id":null,"occurred_at":"2026-07-18 04:24:28"}	2026-07-18 04:24:28+00
b193ee3ec703637415e2aca848024b79	tenant-1e336d48	99c02e67-d06e-476a-a0a1-082f188ecf34	STOCK_ADJUSTED	1	0000000000000000000000000000000000000000000000000000000000000000	6a18586aafdccadeaa4c2ba69948e5cdcfdb618d17f0a56cdc1ca05a07886cde	a1f89b8c63547c4ae095931f7acc20b8accb3447f9b45fd9607382bcbff9232c	{"variant_id":"d30f061f-8fac-47eb-b610-a8a534fb96cf","quantity":1,"reason":"purchase_receipt","reference_id":"PO-HTTP-100","occurred_at":"2026-07-18 04:32:57"}	2026-07-18 04:32:59+00
9209211cf255c9721d3945a9ce9e2225	tenant-5289896b	532ed2df-8b3d-4a0e-8ab3-e287c5ce56aa	STOCK_ADJUSTED	2	1747c524e32a3bcbc0d50045f51792ecb54540ff07b0c9bbc707199c1283db28	2b923b82b303126c0f2dcbe554fc987898f04221a67cd92419f03bc4d89bcab0	f4bb6bd07695765d9c66bd6cc53b42a2f5fc1f580411616367a77fc96e1910ec	{"variant_id":"36d9a767-bdc0-486c-9d9c-de63a086d767","quantity":-1,"reason":"sale","reference_id":"SALE-69043df4","occurred_at":"2026-07-18 04:39:19"}	2026-07-18 04:39:19+00
056c50a78ba726e3a70c05ef61dc49e8	tenant-4daa3c69	398e5bb7-0081-4b7b-a9af-14bfd4fc9c10	STOCK_ADJUSTED	1	0000000000000000000000000000000000000000000000000000000000000000	9afea5c1fd6207b3b37db2e58dde357fd898082204013ac0191095b5da8adcec	7374924fe34e6b6e90445d79ad2c3f358e3a98d6363fb035ade0915d46492d9e	{"variant_id":"SKU-7099D6DE","quantity":10,"reason":"purchase_receipt","reference_id":null,"occurred_at":"2026-07-18 04:41:07"}	2026-07-18 04:41:08+00
\.


--
-- Data for Name: demand_forecasts; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.demand_forecasts (id, sku, location_id, forecasted_quantity, period_start, period_end, confidence_level, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: inventory_cost_layers; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.inventory_cost_layers (id, tenant_id, variant_id, original_quantity, remaining_quantity, unit_cost_cents, purchase_order_id, received_at, serial_number, lot_number, expiration_date) FROM stdin;
4ee0a0dc-ba73-454d-94f2-5b2fbe2335f5	tenant-dd82f00c	TEST-SKU-TRANSIT	6	6	1000	RECEIVE_IN_TRANSIT	2026-07-18 05:06:26	\N	\N	\N
\.


--
-- Data for Name: inventory_count_items; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.inventory_count_items (id, inventory_count_id, product_id, sku, location_id, counted_quantity, created_at) FROM stdin;
\.


--
-- Data for Name: inventory_counts; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.inventory_counts (id, tenant_id, status, created_at, completed_at) FROM stdin;
\.


--
-- Data for Name: inventory_transactions; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.inventory_transactions (id, tenant_id, product_id, type, quantity_change, condition, created_at, reference_id) FROM stdin;
\.


--
-- Data for Name: journal_entries; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.journal_entries (id, tenant_id, entry_date, description, reference_id, method, lines, created_at) FROM stdin;
\.


--
-- Data for Name: kit_components; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.kit_components (id, kit_id, variant_id, quantity) FROM stdin;
\.


--
-- Data for Name: kits; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.kits (id, sku, name, created_at) FROM stdin;
\.


--
-- Data for Name: ledger_entries; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.ledger_entries (id, tenant_id, variant_id, quantity, reason, actor_id, reference_id, occurred_at, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: locations; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.locations (id, name, type, created_at) FROM stdin;
LOC-INT	Integration Location	TEST	2026-07-17 21:26:49.011247+00
\.


--
-- Data for Name: netsuite_journal_mappings; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.netsuite_journal_mappings (id, journal_entry_id, netsuite_journal_id, created_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.notifications (id, tenant_id, title, message, type, is_read, created_at) FROM stdin;
dfedbd15-0e07-44c0-be6d-064e52509477	tenant-dd82f00c	Stock Received	Received 6 units for SKU 'TEST-SKU-TRANSIT' at location 'LOC-INT'.	success	f	2026-07-18 05:06:26
\.


--
-- Data for Name: outbox_events; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.outbox_events (id, event_name, payload, occurred_on, processed_at, attempts, last_error, next_attempt_at) FROM stdin;
\.


--
-- Data for Name: outbox_messages; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.outbox_messages (id, event_type, payload, occurred_at, processed_at) FROM stdin;
\.


--
-- Data for Name: product_locations; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.product_locations (product_id, location_id, stock_quantity, open_box_quantity, damaged_quantity, allocated_quantity, in_transit_quantity, updated_at) FROM stdin;
2f6f7775-fc7a-4b04-92c4-94036e763f1b	LOC-INT	16	0	0	0	4	2026-07-18 05:06:26+00
\.


--
-- Data for Name: product_uom_configurations; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.product_uom_configurations (id, variant_id, base_unit, purchase_unit, sale_unit, created_at) FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.products (id, tenant_id, sku, name, department, reorder_threshold, version_id, weight_grams, volume_cubic_meters, created_at, updated_at) FROM stdin;
2f6f7775-fc7a-4b04-92c4-94036e763f1b	tenant-dd82f00c	TEST-SKU-TRANSIT	Test Transit Product	electronics	5	3	\N	\N	2026-07-18 05:05:53+00	2026-07-18 05:06:26+00
\.


--
-- Data for Name: purchase_order_items; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.purchase_order_items (id, purchase_order_id, variant_id, quantity, received_quantity, unit_cost_cents) FROM stdin;
\.


--
-- Data for Name: purchase_orders; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.purchase_orders (id, purchase_order_number, vendor_id, tenant_id, status, location_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: quarantine_items; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.quarantine_items (id, tenant_id, variant_id, quantity, reason, status, location_id, created_at, resolved_at) FROM stdin;
\.


--
-- Data for Name: queued_jobs; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.queued_jobs (id, tenant_id, listener_class, event_data, attempts, reserved_at, available_at, created_at) FROM stdin;
\.


--
-- Data for Name: quickbooks_journal_mappings; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.quickbooks_journal_mappings (id, journal_entry_id, quickbooks_journal_id, created_at) FROM stdin;
\.


--
-- Data for Name: reorder_policies; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.reorder_policies (id, sku, location_id, reorder_point, reorder_quantity, safety_stock, dynamic_rop_enabled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: rma_items; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.rma_items (id, rma_id, variant_id, quantity, received_quantity, unit_cost_cents, status, disposition, created_at) FROM stdin;
\.


--
-- Data for Name: rmas; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.rmas (id, rma_number, tenant_id, customer_id, location_id, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.role_permissions (role_id, permission) FROM stdin;
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.roles (id, name) FROM stdin;
admin	Administrator
manager	Manager
staff	Staff
\.


--
-- Data for Name: serialized_items; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.serialized_items (id, variant_id, serial_number, tenant_id, location_id, status, history, created_at) FROM stdin;
\.


--
-- Data for Name: shipments; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.shipments (id, sku, quantity, destination_address, carrier, tracking_number, label_url, shipping_rate_cents, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: shopify_location_mappings; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.shopify_location_mappings (id, our_location_id, shopify_location_id, created_at) FROM stdin;
\.


--
-- Data for Name: shopify_sku_mappings; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.shopify_sku_mappings (id, sku, shopify_inventory_item_id, created_at) FROM stdin;
\.


--
-- Data for Name: shopify_sync_failures; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.shopify_sync_failures (id, tenant_id, sku, location_id, quantity, attempts, last_error, status, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: stock_onboarding_items; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.stock_onboarding_items (id, onboarding_id, variant_id, quantity, unit_cost_cents) FROM stdin;
\.


--
-- Data for Name: stock_onboardings; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.stock_onboardings (id, tenant_id, location_id, as_of_date, status, created_at) FROM stdin;
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.tenants (id, name, created_at) FROM stdin;
test-tenant	Test Tenant	2026-07-17 21:26:49.020251+00
tenant-dd82f00c	Test Org dd82f00c	2026-07-18 05:05:47+00
\.


--
-- Data for Name: uom_conversion_rules; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.uom_conversion_rules (id, configuration_id, unit, factor_to_base, label) FROM stdin;
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.user_roles (user_id, role_id) FROM stdin;
6d9534c0-dc83-45f3-9687-68765cdde776	staff
6d9534c0-dc83-45f3-9687-68765cdde776	admin
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.users (id, tenant_id, email, password_hash, name, active, created_at) FROM stdin;
6d9534c0-dc83-45f3-9687-68765cdde776	tenant-dd82f00c	admin-dd82f00c@example.com	$2y$04$p1ltEgrMrCCrjb52YF2wBOyzNNRsDEIqyjhSVTEbcx/On8XHF6ale	Admin User	t	2026-07-18 05:05:48+00
\.


--
-- Data for Name: warehouse_locations; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.warehouse_locations (id, warehouse_id, zone, aisle, rack, shelf, bin, max_weight_grams, max_volume_cubic_meters, grid_x, grid_y, width, height, created_at) FROM stdin;
\.


--
-- Data for Name: webhook_deliveries; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.webhook_deliveries (id, tenant_id, subscription_id, event_type, payload, status, attempts, last_error, next_attempt_at, processed_at, created_at) FROM stdin;
fbf15289-dd6d-42bb-a859-e2a1ce80aaf1	tenant-734d7794	866750c3-77be-4da9-8158-115cc50a0efd	TestEvent	{"sku":"SKU-1"}	Pending	1	HTTP Error Status: 405	2026-07-18 04:54:45+00	\N	2026-07-18 04:54:17+00
\.


--
-- Data for Name: webhook_subscriptions; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.webhook_subscriptions (id, tenant_id, target_url, secret, event_types, is_active, created_at) FROM stdin;
866750c3-77be-4da9-8158-115cc50a0efd	tenant-734d7794	https://example.com/target	sec	["TestEvent"]	t	2026-07-18 04:54:17.155794+00
\.


--
-- Data for Name: xero_journal_mappings; Type: TABLE DATA; Schema: public; Owner: ddd_user
--

COPY public.xero_journal_mappings (id, journal_entry_id, xero_journal_id, created_at) FROM stdin;
\.


--
-- Name: bgw_job_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: ddd_user
--

SELECT pg_catalog.setval('_timescaledb_catalog.bgw_job_id_seq', 1000, true);


--
-- Name: chunk_column_stats_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: ddd_user
--

SELECT pg_catalog.setval('_timescaledb_catalog.chunk_column_stats_id_seq', 1, false);


--
-- Name: chunk_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: ddd_user
--

SELECT pg_catalog.setval('_timescaledb_catalog.chunk_id_seq', 78, true);


--
-- Name: dimension_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: ddd_user
--

SELECT pg_catalog.setval('_timescaledb_catalog.dimension_id_seq', 3, true);


--
-- Name: dimension_slice_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: ddd_user
--

SELECT pg_catalog.setval('_timescaledb_catalog.dimension_slice_id_seq', 78, true);


--
-- Name: hypertable_id_seq; Type: SEQUENCE SET; Schema: _timescaledb_catalog; Owner: ddd_user
--

SELECT pg_catalog.setval('_timescaledb_catalog.hypertable_id_seq', 3, true);


--
-- Name: _hyper_1_78_chunk 78_inventory_transactions_pkey; Type: CONSTRAINT; Schema: _timescaledb_internal; Owner: ddd_user
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_78_chunk
    ADD CONSTRAINT "78_inventory_transactions_pkey" PRIMARY KEY (id, created_at);


--
-- Name: api_tokens api_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.api_tokens
    ADD CONSTRAINT api_tokens_pkey PRIMARY KEY (id);


--
-- Name: api_tokens api_tokens_token_hash_key; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.api_tokens
    ADD CONSTRAINT api_tokens_token_hash_key UNIQUE (token_hash);


--
-- Name: audit_discrepancies audit_discrepancies_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.audit_discrepancies
    ADD CONSTRAINT audit_discrepancies_pkey PRIMARY KEY (id);


--
-- Name: barcodes barcodes_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.barcodes
    ADD CONSTRAINT barcodes_pkey PRIMARY KEY (id);


--
-- Name: barcodes barcodes_value_key; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.barcodes
    ADD CONSTRAINT barcodes_value_key UNIQUE (value);


--
-- Name: catalog_products catalog_products_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.catalog_products
    ADD CONSTRAINT catalog_products_pkey PRIMARY KEY (id);


--
-- Name: catalog_variants catalog_variants_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.catalog_variants
    ADD CONSTRAINT catalog_variants_pkey PRIMARY KEY (id);


--
-- Name: catalog_variants catalog_variants_sku_key; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.catalog_variants
    ADD CONSTRAINT catalog_variants_sku_key UNIQUE (sku);


--
-- Name: compliance_ledgers compliance_ledgers_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.compliance_ledgers
    ADD CONSTRAINT compliance_ledgers_pkey PRIMARY KEY (id);


--
-- Name: demand_forecasts demand_forecasts_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.demand_forecasts
    ADD CONSTRAINT demand_forecasts_pkey PRIMARY KEY (id);


--
-- Name: demand_forecasts demand_forecasts_sku_location_id_period_start_period_end_key; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.demand_forecasts
    ADD CONSTRAINT demand_forecasts_sku_location_id_period_start_period_end_key UNIQUE (sku, location_id, period_start, period_end);


--
-- Name: inventory_cost_layers inventory_cost_layers_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.inventory_cost_layers
    ADD CONSTRAINT inventory_cost_layers_pkey PRIMARY KEY (id);


--
-- Name: inventory_count_items inventory_count_items_inventory_count_id_sku_location_id_key; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.inventory_count_items
    ADD CONSTRAINT inventory_count_items_inventory_count_id_sku_location_id_key UNIQUE (inventory_count_id, sku, location_id);


--
-- Name: inventory_count_items inventory_count_items_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.inventory_count_items
    ADD CONSTRAINT inventory_count_items_pkey PRIMARY KEY (id);


--
-- Name: inventory_counts inventory_counts_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.inventory_counts
    ADD CONSTRAINT inventory_counts_pkey PRIMARY KEY (id);


--
-- Name: inventory_transactions inventory_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.inventory_transactions
    ADD CONSTRAINT inventory_transactions_pkey PRIMARY KEY (id, created_at);


--
-- Name: journal_entries journal_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_pkey PRIMARY KEY (id);


--
-- Name: kit_components kit_components_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.kit_components
    ADD CONSTRAINT kit_components_pkey PRIMARY KEY (id);


--
-- Name: kits kits_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.kits
    ADD CONSTRAINT kits_pkey PRIMARY KEY (id);


--
-- Name: kits kits_sku_key; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.kits
    ADD CONSTRAINT kits_sku_key UNIQUE (sku);


--
-- Name: ledger_entries ledger_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.ledger_entries
    ADD CONSTRAINT ledger_entries_pkey PRIMARY KEY (id, occurred_at);


--
-- Name: locations locations_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_pkey PRIMARY KEY (id);


--
-- Name: netsuite_journal_mappings netsuite_journal_mappings_journal_entry_id_key; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.netsuite_journal_mappings
    ADD CONSTRAINT netsuite_journal_mappings_journal_entry_id_key UNIQUE (journal_entry_id);


--
-- Name: netsuite_journal_mappings netsuite_journal_mappings_netsuite_journal_id_key; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.netsuite_journal_mappings
    ADD CONSTRAINT netsuite_journal_mappings_netsuite_journal_id_key UNIQUE (netsuite_journal_id);


--
-- Name: netsuite_journal_mappings netsuite_journal_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.netsuite_journal_mappings
    ADD CONSTRAINT netsuite_journal_mappings_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: outbox_events outbox_events_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.outbox_events
    ADD CONSTRAINT outbox_events_pkey PRIMARY KEY (id);


--
-- Name: outbox_messages outbox_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.outbox_messages
    ADD CONSTRAINT outbox_messages_pkey PRIMARY KEY (id);


--
-- Name: product_locations product_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.product_locations
    ADD CONSTRAINT product_locations_pkey PRIMARY KEY (product_id, location_id);


--
-- Name: product_uom_configurations product_uom_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.product_uom_configurations
    ADD CONSTRAINT product_uom_configurations_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: products products_tenant_id_sku_key; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_tenant_id_sku_key UNIQUE (tenant_id, sku);


--
-- Name: purchase_order_items purchase_order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT purchase_order_items_pkey PRIMARY KEY (id);


--
-- Name: purchase_orders purchase_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_pkey PRIMARY KEY (id);


--
-- Name: purchase_orders purchase_orders_purchase_order_number_key; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_purchase_order_number_key UNIQUE (purchase_order_number);


--
-- Name: quarantine_items quarantine_items_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.quarantine_items
    ADD CONSTRAINT quarantine_items_pkey PRIMARY KEY (id);


--
-- Name: queued_jobs queued_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.queued_jobs
    ADD CONSTRAINT queued_jobs_pkey PRIMARY KEY (id);


--
-- Name: quickbooks_journal_mappings quickbooks_journal_mappings_journal_entry_id_key; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.quickbooks_journal_mappings
    ADD CONSTRAINT quickbooks_journal_mappings_journal_entry_id_key UNIQUE (journal_entry_id);


--
-- Name: quickbooks_journal_mappings quickbooks_journal_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.quickbooks_journal_mappings
    ADD CONSTRAINT quickbooks_journal_mappings_pkey PRIMARY KEY (id);


--
-- Name: quickbooks_journal_mappings quickbooks_journal_mappings_quickbooks_journal_id_key; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.quickbooks_journal_mappings
    ADD CONSTRAINT quickbooks_journal_mappings_quickbooks_journal_id_key UNIQUE (quickbooks_journal_id);


--
-- Name: reorder_policies reorder_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.reorder_policies
    ADD CONSTRAINT reorder_policies_pkey PRIMARY KEY (id);


--
-- Name: reorder_policies reorder_policies_sku_location_id_key; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.reorder_policies
    ADD CONSTRAINT reorder_policies_sku_location_id_key UNIQUE (sku, location_id);


--
-- Name: rma_items rma_items_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.rma_items
    ADD CONSTRAINT rma_items_pkey PRIMARY KEY (id);


--
-- Name: rmas rmas_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.rmas
    ADD CONSTRAINT rmas_pkey PRIMARY KEY (id);


--
-- Name: rmas rmas_rma_number_key; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.rmas
    ADD CONSTRAINT rmas_rma_number_key UNIQUE (rma_number);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (role_id, permission);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: serialized_items serialized_items_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.serialized_items
    ADD CONSTRAINT serialized_items_pkey PRIMARY KEY (id);


--
-- Name: serialized_items serialized_items_serial_number_tenant_id_key; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.serialized_items
    ADD CONSTRAINT serialized_items_serial_number_tenant_id_key UNIQUE (serial_number, tenant_id);


--
-- Name: shipments shipments_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.shipments
    ADD CONSTRAINT shipments_pkey PRIMARY KEY (id);


--
-- Name: shopify_location_mappings shopify_location_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.shopify_location_mappings
    ADD CONSTRAINT shopify_location_mappings_pkey PRIMARY KEY (id);


--
-- Name: shopify_location_mappings shopify_location_mappings_shopify_location_id_key; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.shopify_location_mappings
    ADD CONSTRAINT shopify_location_mappings_shopify_location_id_key UNIQUE (shopify_location_id);


--
-- Name: shopify_sku_mappings shopify_sku_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.shopify_sku_mappings
    ADD CONSTRAINT shopify_sku_mappings_pkey PRIMARY KEY (id);


--
-- Name: shopify_sku_mappings shopify_sku_mappings_shopify_inventory_item_id_key; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.shopify_sku_mappings
    ADD CONSTRAINT shopify_sku_mappings_shopify_inventory_item_id_key UNIQUE (shopify_inventory_item_id);


--
-- Name: shopify_sku_mappings shopify_sku_mappings_sku_key; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.shopify_sku_mappings
    ADD CONSTRAINT shopify_sku_mappings_sku_key UNIQUE (sku);


--
-- Name: shopify_sync_failures shopify_sync_failures_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.shopify_sync_failures
    ADD CONSTRAINT shopify_sync_failures_pkey PRIMARY KEY (id);


--
-- Name: stock_onboarding_items stock_onboarding_items_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.stock_onboarding_items
    ADD CONSTRAINT stock_onboarding_items_pkey PRIMARY KEY (id);


--
-- Name: stock_onboardings stock_onboardings_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.stock_onboardings
    ADD CONSTRAINT stock_onboardings_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: uom_conversion_rules uom_conversion_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.uom_conversion_rules
    ADD CONSTRAINT uom_conversion_rules_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (user_id, role_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_tenant_id_email_key; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tenant_id_email_key UNIQUE (tenant_id, email);


--
-- Name: warehouse_locations warehouse_locations_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.warehouse_locations
    ADD CONSTRAINT warehouse_locations_pkey PRIMARY KEY (id);


--
-- Name: warehouse_locations warehouse_locations_warehouse_id_zone_aisle_rack_shelf_bin_key; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.warehouse_locations
    ADD CONSTRAINT warehouse_locations_warehouse_id_zone_aisle_rack_shelf_bin_key UNIQUE (warehouse_id, zone, aisle, rack, shelf, bin);


--
-- Name: webhook_deliveries webhook_deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.webhook_deliveries
    ADD CONSTRAINT webhook_deliveries_pkey PRIMARY KEY (id);


--
-- Name: webhook_subscriptions webhook_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.webhook_subscriptions
    ADD CONSTRAINT webhook_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: xero_journal_mappings xero_journal_mappings_journal_entry_id_key; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.xero_journal_mappings
    ADD CONSTRAINT xero_journal_mappings_journal_entry_id_key UNIQUE (journal_entry_id);


--
-- Name: xero_journal_mappings xero_journal_mappings_pkey; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.xero_journal_mappings
    ADD CONSTRAINT xero_journal_mappings_pkey PRIMARY KEY (id);


--
-- Name: xero_journal_mappings xero_journal_mappings_xero_journal_id_key; Type: CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.xero_journal_mappings
    ADD CONSTRAINT xero_journal_mappings_xero_journal_id_key UNIQUE (xero_journal_id);


--
-- Name: _hyper_1_78_chunk_idx_inventory_transactions_tenant; Type: INDEX; Schema: _timescaledb_internal; Owner: ddd_user
--

CREATE INDEX _hyper_1_78_chunk_idx_inventory_transactions_tenant ON _timescaledb_internal._hyper_1_78_chunk USING btree (tenant_id);


--
-- Name: _hyper_1_78_chunk_inventory_transactions_created_at_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: ddd_user
--

CREATE INDEX _hyper_1_78_chunk_inventory_transactions_created_at_idx ON _timescaledb_internal._hyper_1_78_chunk USING btree (created_at DESC);


--
-- Name: _hyper_3_44_chunk__materialized_hypertable_3_bucket_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: ddd_user
--

CREATE INDEX _hyper_3_44_chunk__materialized_hypertable_3_bucket_idx ON _timescaledb_internal._hyper_3_44_chunk USING btree (bucket DESC);


--
-- Name: _hyper_3_44_chunk__materialized_hypertable_3_tenant_id_bucket_i; Type: INDEX; Schema: _timescaledb_internal; Owner: ddd_user
--

CREATE INDEX _hyper_3_44_chunk__materialized_hypertable_3_tenant_id_bucket_i ON _timescaledb_internal._hyper_3_44_chunk USING btree (tenant_id, bucket DESC);


--
-- Name: _hyper_3_44_chunk__materialized_hypertable_3_variant_id_bucket_; Type: INDEX; Schema: _timescaledb_internal; Owner: ddd_user
--

CREATE INDEX _hyper_3_44_chunk__materialized_hypertable_3_variant_id_bucket_ ON _timescaledb_internal._hyper_3_44_chunk USING btree (variant_id, bucket DESC);


--
-- Name: _materialized_hypertable_3_bucket_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: ddd_user
--

CREATE INDEX _materialized_hypertable_3_bucket_idx ON _timescaledb_internal._materialized_hypertable_3 USING btree (bucket DESC);


--
-- Name: _materialized_hypertable_3_tenant_id_bucket_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: ddd_user
--

CREATE INDEX _materialized_hypertable_3_tenant_id_bucket_idx ON _timescaledb_internal._materialized_hypertable_3 USING btree (tenant_id, bucket DESC);


--
-- Name: _materialized_hypertable_3_variant_id_bucket_idx; Type: INDEX; Schema: _timescaledb_internal; Owner: ddd_user
--

CREATE INDEX _materialized_hypertable_3_variant_id_bucket_idx ON _timescaledb_internal._materialized_hypertable_3 USING btree (variant_id, bucket DESC);


--
-- Name: idx_api_tokens_hash; Type: INDEX; Schema: public; Owner: ddd_user
--

CREATE INDEX idx_api_tokens_hash ON public.api_tokens USING btree (token_hash);


--
-- Name: idx_barcodes_value; Type: INDEX; Schema: public; Owner: ddd_user
--

CREATE INDEX idx_barcodes_value ON public.barcodes USING btree (value);


--
-- Name: idx_barcodes_variant; Type: INDEX; Schema: public; Owner: ddd_user
--

CREATE INDEX idx_barcodes_variant ON public.barcodes USING btree (variant_id);


--
-- Name: idx_cost_layers_serial; Type: INDEX; Schema: public; Owner: ddd_user
--

CREATE INDEX idx_cost_layers_serial ON public.inventory_cost_layers USING btree (serial_number);


--
-- Name: idx_cost_layers_tenant; Type: INDEX; Schema: public; Owner: ddd_user
--

CREATE INDEX idx_cost_layers_tenant ON public.inventory_cost_layers USING btree (tenant_id);


--
-- Name: idx_cost_layers_variant; Type: INDEX; Schema: public; Owner: ddd_user
--

CREATE INDEX idx_cost_layers_variant ON public.inventory_cost_layers USING btree (variant_id);


--
-- Name: idx_demand_forecasts_sku_loc; Type: INDEX; Schema: public; Owner: ddd_user
--

CREATE INDEX idx_demand_forecasts_sku_loc ON public.demand_forecasts USING btree (sku, location_id);


--
-- Name: idx_inventory_count_items_inventory_count_id; Type: INDEX; Schema: public; Owner: ddd_user
--

CREATE INDEX idx_inventory_count_items_inventory_count_id ON public.inventory_count_items USING btree (inventory_count_id);


--
-- Name: idx_inventory_counts_tenant; Type: INDEX; Schema: public; Owner: ddd_user
--

CREATE INDEX idx_inventory_counts_tenant ON public.inventory_counts USING btree (tenant_id);


--
-- Name: idx_inventory_transactions_tenant; Type: INDEX; Schema: public; Owner: ddd_user
--

CREATE INDEX idx_inventory_transactions_tenant ON public.inventory_transactions USING btree (tenant_id);


--
-- Name: idx_ledger_tenant; Type: INDEX; Schema: public; Owner: ddd_user
--

CREATE INDEX idx_ledger_tenant ON public.ledger_entries USING btree (tenant_id);


--
-- Name: idx_ledger_variant; Type: INDEX; Schema: public; Owner: ddd_user
--

CREATE INDEX idx_ledger_variant ON public.ledger_entries USING btree (variant_id);


--
-- Name: idx_netsuite_journal_mappings_local; Type: INDEX; Schema: public; Owner: ddd_user
--

CREATE INDEX idx_netsuite_journal_mappings_local ON public.netsuite_journal_mappings USING btree (journal_entry_id);


--
-- Name: idx_notifications_tenant; Type: INDEX; Schema: public; Owner: ddd_user
--

CREATE INDEX idx_notifications_tenant ON public.notifications USING btree (tenant_id);


--
-- Name: idx_onboarding_variant; Type: INDEX; Schema: public; Owner: ddd_user
--

CREATE INDEX idx_onboarding_variant ON public.stock_onboarding_items USING btree (variant_id);


--
-- Name: idx_products_sku; Type: INDEX; Schema: public; Owner: ddd_user
--

CREATE INDEX idx_products_sku ON public.products USING btree (sku);


--
-- Name: idx_products_tenant; Type: INDEX; Schema: public; Owner: ddd_user
--

CREATE INDEX idx_products_tenant ON public.products USING btree (tenant_id);


--
-- Name: idx_quarantine_items_tenant; Type: INDEX; Schema: public; Owner: ddd_user
--

CREATE INDEX idx_quarantine_items_tenant ON public.quarantine_items USING btree (tenant_id);


--
-- Name: idx_queued_jobs_available_at; Type: INDEX; Schema: public; Owner: ddd_user
--

CREATE INDEX idx_queued_jobs_available_at ON public.queued_jobs USING btree (available_at);


--
-- Name: idx_queued_jobs_tenant_id; Type: INDEX; Schema: public; Owner: ddd_user
--

CREATE INDEX idx_queued_jobs_tenant_id ON public.queued_jobs USING btree (tenant_id);


--
-- Name: idx_quickbooks_journal_mappings_local; Type: INDEX; Schema: public; Owner: ddd_user
--

CREATE INDEX idx_quickbooks_journal_mappings_local ON public.quickbooks_journal_mappings USING btree (journal_entry_id);


--
-- Name: idx_rma_items_rma; Type: INDEX; Schema: public; Owner: ddd_user
--

CREATE INDEX idx_rma_items_rma ON public.rma_items USING btree (rma_id);


--
-- Name: idx_rmas_tenant; Type: INDEX; Schema: public; Owner: ddd_user
--

CREATE INDEX idx_rmas_tenant ON public.rmas USING btree (tenant_id);


--
-- Name: idx_serial_tenant; Type: INDEX; Schema: public; Owner: ddd_user
--

CREATE INDEX idx_serial_tenant ON public.serialized_items USING btree (tenant_id);


--
-- Name: idx_serial_variant; Type: INDEX; Schema: public; Owner: ddd_user
--

CREATE INDEX idx_serial_variant ON public.serialized_items USING btree (variant_id);


--
-- Name: idx_shopify_location_mappings_shopify_id; Type: INDEX; Schema: public; Owner: ddd_user
--

CREATE INDEX idx_shopify_location_mappings_shopify_id ON public.shopify_location_mappings USING btree (shopify_location_id);


--
-- Name: idx_shopify_sku_mappings_sku; Type: INDEX; Schema: public; Owner: ddd_user
--

CREATE INDEX idx_shopify_sku_mappings_sku ON public.shopify_sku_mappings USING btree (sku);


--
-- Name: idx_shopify_sync_failures_status; Type: INDEX; Schema: public; Owner: ddd_user
--

CREATE INDEX idx_shopify_sync_failures_status ON public.shopify_sync_failures USING btree (status);


--
-- Name: idx_shopify_sync_failures_tenant; Type: INDEX; Schema: public; Owner: ddd_user
--

CREATE INDEX idx_shopify_sync_failures_tenant ON public.shopify_sync_failures USING btree (tenant_id);


--
-- Name: idx_users_tenant_email; Type: INDEX; Schema: public; Owner: ddd_user
--

CREATE INDEX idx_users_tenant_email ON public.users USING btree (tenant_id, email);


--
-- Name: idx_xero_journal_mappings_local; Type: INDEX; Schema: public; Owner: ddd_user
--

CREATE INDEX idx_xero_journal_mappings_local ON public.xero_journal_mappings USING btree (journal_entry_id);


--
-- Name: inventory_transactions_created_at_idx; Type: INDEX; Schema: public; Owner: ddd_user
--

CREATE INDEX inventory_transactions_created_at_idx ON public.inventory_transactions USING btree (created_at DESC);


--
-- Name: ledger_entries_occurred_at_idx; Type: INDEX; Schema: public; Owner: ddd_user
--

CREATE INDEX ledger_entries_occurred_at_idx ON public.ledger_entries USING btree (occurred_at DESC);


--
-- Name: _hyper_1_78_chunk inventory_transactions_product_id_fkey; Type: FK CONSTRAINT; Schema: _timescaledb_internal; Owner: ddd_user
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_78_chunk
    ADD CONSTRAINT inventory_transactions_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: _hyper_1_78_chunk inventory_transactions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: _timescaledb_internal; Owner: ddd_user
--

ALTER TABLE ONLY _timescaledb_internal._hyper_1_78_chunk
    ADD CONSTRAINT inventory_transactions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: api_tokens api_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.api_tokens
    ADD CONSTRAINT api_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: catalog_variants catalog_variants_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.catalog_variants
    ADD CONSTRAINT catalog_variants_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.catalog_products(id) ON DELETE CASCADE;


--
-- Name: demand_forecasts demand_forecasts_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.demand_forecasts
    ADD CONSTRAINT demand_forecasts_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.locations(id) ON DELETE CASCADE;


--
-- Name: inventory_count_items inventory_count_items_inventory_count_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.inventory_count_items
    ADD CONSTRAINT inventory_count_items_inventory_count_id_fkey FOREIGN KEY (inventory_count_id) REFERENCES public.inventory_counts(id) ON DELETE CASCADE;


--
-- Name: inventory_count_items inventory_count_items_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.inventory_count_items
    ADD CONSTRAINT inventory_count_items_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE SET NULL;


--
-- Name: inventory_counts inventory_counts_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.inventory_counts
    ADD CONSTRAINT inventory_counts_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: inventory_transactions inventory_transactions_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.inventory_transactions
    ADD CONSTRAINT inventory_transactions_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: inventory_transactions inventory_transactions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.inventory_transactions
    ADD CONSTRAINT inventory_transactions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: journal_entries journal_entries_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.journal_entries
    ADD CONSTRAINT journal_entries_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: kit_components kit_components_kit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.kit_components
    ADD CONSTRAINT kit_components_kit_id_fkey FOREIGN KEY (kit_id) REFERENCES public.kits(id) ON DELETE CASCADE;


--
-- Name: ledger_entries ledger_entries_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.ledger_entries
    ADD CONSTRAINT ledger_entries_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: netsuite_journal_mappings netsuite_journal_mappings_journal_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.netsuite_journal_mappings
    ADD CONSTRAINT netsuite_journal_mappings_journal_entry_id_fkey FOREIGN KEY (journal_entry_id) REFERENCES public.journal_entries(id) ON DELETE CASCADE;


--
-- Name: product_locations product_locations_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.product_locations
    ADD CONSTRAINT product_locations_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.locations(id) ON DELETE CASCADE;


--
-- Name: product_locations product_locations_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.product_locations
    ADD CONSTRAINT product_locations_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: products products_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: purchase_order_items purchase_order_items_purchase_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.purchase_order_items
    ADD CONSTRAINT purchase_order_items_purchase_order_id_fkey FOREIGN KEY (purchase_order_id) REFERENCES public.purchase_orders(id) ON DELETE CASCADE;


--
-- Name: purchase_orders purchase_orders_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.locations(id) ON DELETE CASCADE;


--
-- Name: purchase_orders purchase_orders_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: quarantine_items quarantine_items_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.quarantine_items
    ADD CONSTRAINT quarantine_items_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.locations(id) ON DELETE CASCADE;


--
-- Name: quarantine_items quarantine_items_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.quarantine_items
    ADD CONSTRAINT quarantine_items_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: quickbooks_journal_mappings quickbooks_journal_mappings_journal_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.quickbooks_journal_mappings
    ADD CONSTRAINT quickbooks_journal_mappings_journal_entry_id_fkey FOREIGN KEY (journal_entry_id) REFERENCES public.journal_entries(id) ON DELETE CASCADE;


--
-- Name: reorder_policies reorder_policies_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.reorder_policies
    ADD CONSTRAINT reorder_policies_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.locations(id) ON DELETE CASCADE;


--
-- Name: rma_items rma_items_rma_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.rma_items
    ADD CONSTRAINT rma_items_rma_id_fkey FOREIGN KEY (rma_id) REFERENCES public.rmas(id) ON DELETE CASCADE;


--
-- Name: rmas rmas_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.rmas
    ADD CONSTRAINT rmas_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.locations(id) ON DELETE CASCADE;


--
-- Name: rmas rmas_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.rmas
    ADD CONSTRAINT rmas_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: serialized_items serialized_items_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.serialized_items
    ADD CONSTRAINT serialized_items_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: shopify_location_mappings shopify_location_mappings_our_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.shopify_location_mappings
    ADD CONSTRAINT shopify_location_mappings_our_location_id_fkey FOREIGN KEY (our_location_id) REFERENCES public.locations(id) ON DELETE CASCADE;


--
-- Name: shopify_sku_mappings shopify_sku_mappings_sku_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.shopify_sku_mappings
    ADD CONSTRAINT shopify_sku_mappings_sku_fkey FOREIGN KEY (sku) REFERENCES public.catalog_variants(sku) ON DELETE CASCADE;


--
-- Name: shopify_sync_failures shopify_sync_failures_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.shopify_sync_failures
    ADD CONSTRAINT shopify_sync_failures_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: stock_onboarding_items stock_onboarding_items_onboarding_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.stock_onboarding_items
    ADD CONSTRAINT stock_onboarding_items_onboarding_id_fkey FOREIGN KEY (onboarding_id) REFERENCES public.stock_onboardings(id) ON DELETE CASCADE;


--
-- Name: stock_onboardings stock_onboardings_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.stock_onboardings
    ADD CONSTRAINT stock_onboardings_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: uom_conversion_rules uom_conversion_rules_configuration_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.uom_conversion_rules
    ADD CONSTRAINT uom_conversion_rules_configuration_id_fkey FOREIGN KEY (configuration_id) REFERENCES public.product_uom_configurations(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: xero_journal_mappings xero_journal_mappings_journal_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ddd_user
--

ALTER TABLE ONLY public.xero_journal_mappings
    ADD CONSTRAINT xero_journal_mappings_journal_entry_id_fkey FOREIGN KEY (journal_entry_id) REFERENCES public.journal_entries(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict zf93GDfzhNR21BBu677TWMtszeeqcpSaXXiLicsRULBFlaP5fMsmjNG25RYIEbK

